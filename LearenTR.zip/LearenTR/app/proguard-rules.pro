# Add project specific ProGuard rules here.
# Not used in the debug build; kept for future release builds.
