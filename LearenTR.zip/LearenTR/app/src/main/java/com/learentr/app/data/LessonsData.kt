package com.learentr.app.data

object LessonsData {

    val a1Lessons: List<Lesson> = listOf(
        Lesson(
            id = 1,
            titleAr = "التحيات",
            icon = "👋",
            words = listOf(
                Word("Merhaba", "مرحبا", "مer-ha-با", "Merhaba, nasılsın?", "مرحبا، كيف حالك؟"),
                Word("Günaydın", "صباح الخير", "غون-آي-دن", "Günaydın, iyi uyudun mu?", "صباح الخير، هل نمت جيدًا؟"),
                Word("İyi akşamlar", "مساء الخير", "إيي آكشام-لار", "İyi akşamlar arkadaşım.", "مساء الخير يا صديقي."),
                Word("Hoşça kal", "مع السلامة", "هوش-تشا كال", "Hoşça kal, görüşürüz.", "مع السلامة، أراك لاحقًا."),
                Word("Teşekkür ederim", "شكرًا لك", "تشكور إديريم", "Yardımın için teşekkür ederim.", "شكرًا لك على مساعدتك."),
                Word("Lütfen", "من فضلك", "لوت-فن", "Bana yardım et, lütfen.", "ساعدني من فضلك."),
                Word("Evet", "نعم", "إيفيت", "Evet, doğru.", "نعم، هذا صحيح."),
                Word("Hayır", "لا", "ها-يير", "Hayır, teşekkürler.", "لا، شكرًا.")
            )
        ),
        Lesson(
            id = 2,
            titleAr = "الأرقام",
            icon = "🔢",
            words = listOf(
                Word("bir", "واحد", "بير", "Bir elmam var.", "لدي تفاحة واحدة."),
                Word("iki", "اثنان", "إيكي", "İki kardeşim var.", "لدي أخوان."),
                Word("üç", "ثلاثة", "أوتش", "Üç kitap okudum.", "قرأت ثلاثة كتب."),
                Word("dört", "أربعة", "دورت", "Saat dört oldu.", "أصبحت الساعة الرابعة."),
                Word("beş", "خمسة", "بش", "Beş gün kaldı.", "بقيت خمسة أيام."),
                Word("altı", "ستة", "ألتي", "Altı öğrenci geldi.", "جاء ستة طلاب."),
                Word("yedi", "سبعة", "يدي", "Yedi yaşındayım.", "عمري سبع سنوات."),
                Word("sekiz", "ثمانية", "سكيز", "Sekiz saat çalıştım.", "عملت ثماني ساعات.")
            )
        ),
        Lesson(
            id = 3,
            titleAr = "العائلة",
            icon = "👪",
            words = listOf(
                Word("anne", "أم", "آنّه", "Annem çok iyi biri.", "أمي شخص طيب جدًا."),
                Word("baba", "أب", "بابا", "Babam doktordur.", "أبي طبيب."),
                Word("kardeş", "أخ / أخت", "كارداش", "Bir kardeşim var.", "لدي أخ واحد."),
                Word("abla", "الأخت الكبرى", "أبلا", "Ablam öğretmen.", "أختي الكبرى معلمة."),
                Word("abi", "الأخ الكبير", "أبي", "Abim İstanbul'da yaşıyor.", "أخي الكبير يعيش في إسطنبول."),
                Word("dede", "جد", "ديدّه", "Dedem çiftçiydi.", "كان جدي مزارعًا."),
                Word("anneanne", "جدة (من جهة الأم)", "آنّه-آنّه", "Anneannem yemek yapıyor.", "جدتي تطبخ الطعام."),
                Word("aile", "عائلة", "آيله", "Ailem çok kalabalık.", "عائلتي كبيرة جدًا.")
            )
        ),
        Lesson(
            id = 4,
            titleAr = "الألوان",
            icon = "🎨",
            words = listOf(
                Word("kırmızı", "أحمر", "كرمزي", "Elma kırmızı.", "التفاحة حمراء."),
                Word("mavi", "أزرق", "مافي", "Gökyüzü mavi.", "السماء زرقاء."),
                Word("yeşil", "أخضر", "يشيل", "Ağaç yeşil.", "الشجرة خضراء."),
                Word("sarı", "أصفر", "ساري", "Güneş sarı.", "الشمس صفراء."),
                Word("siyah", "أسود", "سياه", "Kedim siyah.", "قطتي سوداء."),
                Word("beyaz", "أبيض", "بياض", "Kar beyaz.", "الثلج أبيض."),
                Word("turuncu", "برتقالي", "تورونجو", "Portakal turuncu.", "البرتقال برتقالي."),
                Word("mor", "بنفسجي", "مور", "Çiçek mor.", "الزهرة بنفسجية.")
            )
        ),
        Lesson(
            id = 5,
            titleAr = "الطعام",
            icon = "🍎",
            words = listOf(
                Word("ekmek", "خبز", "أكمك", "Sabah ekmek yedim.", "أكلت خبزًا في الصباح."),
                Word("su", "ماء", "سو", "Su içmek istiyorum.", "أريد أن أشرب ماء."),
                Word("elma", "تفاحة", "إلما", "Bir elma aldım.", "اشتريت تفاحة."),
                Word("süt", "حليب", "سوت", "Süt seviyor musun?", "هل تحب الحليب؟"),
                Word("çay", "شاي", "تشاي", "Türk çayı çok güzel.", "الشاي التركي لذيذ جدًا."),
                Word("kahve", "قهوة", "كهفه", "Kahve içer misin?", "هل تشرب قهوة؟"),
                Word("et", "لحم", "إت", "Bugün et yedik.", "أكلنا لحمًا اليوم."),
                Word("peynir", "جبن", "پينير", "Kahvaltıda peynir var.", "يوجد جبن في الفطور.")
            )
        ),
        Lesson(
            id = 6,
            titleAr = "المدرسة",
            icon = "🏫",
            words = listOf(
                Word("okul", "مدرسة", "أوكول", "Okula gidiyorum.", "أذهب إلى المدرسة."),
                Word("öğretmen", "معلم", "أوغرتمن", "Öğretmenim çok iyi.", "معلمي جيد جدًا."),
                Word("öğrenci", "طالب", "أوغرنجي", "Ben bir öğrenciyim.", "أنا طالب."),
                Word("kitap", "كتاب", "كيتاب", "Kitap okumayı seviyorum.", "أحب قراءة الكتب."),
                Word("kalem", "قلم", "كالم", "Kalemim kayboldu.", "ضاع قلمي."),
                Word("defter", "دفتر", "دفتر", "Defterime yazdım.", "كتبت في دفتري."),
                Word("sınıf", "صف", "سنف", "Sınıfımız büyük.", "صفنا كبير."),
                Word("ders", "درس", "درس", "Ders çok zor.", "الدرس صعب جدًا.")
            )
        ),
        Lesson(
            id = 7,
            titleAr = "الأفعال الأساسية",
            icon = "🏃",
            words = listOf(
                Word("gitmek", "الذهاب", "غيتمك", "Okula gitmek istiyorum.", "أريد الذهاب إلى المدرسة."),
                Word("gelmek", "المجيء", "غلمك", "Yarın gelmek istiyor.", "يريد المجيء غدًا."),
                Word("yemek", "الأكل", "يمك", "Yemek yemek çok güzel.", "الأكل ممتع جدًا."),
                Word("içmek", "الشرب", "إيتشمك", "Su içmek gerekiyor.", "يجب شرب الماء."),
                Word("okumak", "القراءة", "أوكوماك", "Kitap okumak faydalıdır.", "قراءة الكتاب مفيدة."),
                Word("yazmak", "الكتابة", "يازماك", "Mektup yazmak istiyorum.", "أريد كتابة رسالة."),
                Word("uyumak", "النوم", "أويوماك", "Erken uyumak lazım.", "يجب النوم مبكرًا."),
                Word("konuşmak", "التحدث", "كونوشماك", "Türkçe konuşmak istiyorum.", "أريد التحدث بالتركية.")
            )
        ),
        Lesson(
            id = 8,
            titleAr = "الجمل اليومية",
            icon = "💬",
            words = listOf(
                Word("Nasılsın?", "كيف حالك؟", "ناسل-سن", "Merhaba, nasılsın?", "مرحبا، كيف حالك؟"),
                Word("İyiyim", "أنا بخير", "إيي-ييم", "İyiyim, teşekkürler.", "أنا بخير، شكرًا."),
                Word("Adın ne?", "ما اسمك؟", "آدن نه", "Adın ne, arkadaşım?", "ما اسمك يا صديقي؟"),
                Word("Benim adım...", "اسمي...", "بنيم آدم", "Benim adım Ahmet.", "اسمي أحمد."),
                Word("Nerelisin?", "من أين أنت؟", "نره-لي-سن", "Nerelisin, Türkiye'den mi?", "من أين أنت، هل أنت من تركيا؟"),
                Word("Anlamıyorum", "لا أفهم", "آنلاميوروم", "Üzgünüm, anlamıyorum.", "آسف، لا أفهم."),
                Word("Saat kaç?", "كم الساعة؟", "سآت كاتش", "Saat kaç şimdi?", "كم الساعة الآن؟"),
                Word("Görüşürüz", "أراك لاحقًا", "غوروشوروز", "Görüşürüz, hoşça kal.", "أراك لاحقًا، مع السلامة.")
            )
        ),
        Lesson(
            id = 9,
            titleAr = "الوقت والأيام",
            icon = "🕒",
            words = listOf(
                Word("bugün", "اليوم", "بوغون", "Bugün hava güzel.", "الطقس جميل اليوم."),
                Word("yarın", "غدًا", "يارن", "Yarın okula gidiyorum.", "سأذهب إلى المدرسة غدًا."),
                Word("dün", "أمس", "دون", "Dün çok yorgundum.", "كنت متعبًا جدًا أمس."),
                Word("pazartesi", "الاثنين", "پازارتسي", "Pazartesi günü çalışıyorum.", "أعمل يوم الاثنين."),
                Word("salı", "الثلاثاء", "سالي", "Salı günü tatil.", "يوم الثلاثاء عطلة."),
                Word("hafta", "أسبوع", "هفتا", "Bu hafta çok yoğunum.", "أنا مشغول جدًا هذا الأسبوع."),
                Word("ay", "شهر", "آي", "Bu ay Türkiye'ye gidiyorum.", "سأذهب إلى تركيا هذا الشهر."),
                Word("saat", "ساعة", "سآت", "Bir saat bekledim.", "انتظرت ساعة واحدة.")
            )
        ),
        Lesson(
            id = 10,
            titleAr = "الأماكن",
            icon = "📍",
            words = listOf(
                Word("ev", "منزل", "إف", "Evim çok küçük.", "منزلي صغير جدًا."),
                Word("sokak", "شارع", "سوكاك", "Bu sokak çok sessiz.", "هذا الشارع هادئ جدًا."),
                Word("şehir", "مدينة", "شهير", "İstanbul büyük bir şehir.", "إسطنبول مدينة كبيرة."),
                Word("hastane", "مستشفى", "هستانه", "Hastaneye gitmem lazım.", "يجب أن أذهب إلى المستشفى."),
                Word("market", "متجر", "ماركت", "Marketten süt aldım.", "اشتريت حليبًا من المتجر."),
                Word("park", "حديقة", "پارك", "Parkta yürüyüş yaptık.", "تمشينا في الحديقة."),
                Word("otel", "فندق", "أوتيل", "Otelimiz çok güzel.", "فندقنا جميل جدًا."),
                Word("havalimanı", "مطار", "هوالي-ماني", "Havalimanına gitmeliyim.", "يجب أن أذهب إلى المطار.")
            )
        )
    )
}
