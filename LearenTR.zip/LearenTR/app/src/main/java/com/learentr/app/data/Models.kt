package com.learentr.app.data

data class Word(
    val tr: String,
    val ar: String,
    val pronunciation: String,
    val exampleTr: String,
    val exampleAr: String
)

data class Lesson(
    val id: Int,
    val titleAr: String,
    val icon: String,
    val words: List<Word>
)
