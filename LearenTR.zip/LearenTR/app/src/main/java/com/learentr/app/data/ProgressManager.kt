package com.learentr.app.data

import android.content.Context
import android.content.SharedPreferences
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Stores all user progress locally on the device using SharedPreferences.
 * No network calls, no account needed.
 */
class ProgressManager(context: Context) {

    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences("learen_progress", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_XP = "xp"
        private const val KEY_STREAK = "streak"
        private const val KEY_LAST_DATE = "last_active_date"
        private const val KEY_COMPLETED_LESSONS = "completed_lessons"
        private const val KEY_LEARNED_WORDS = "learned_words"
        private val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    }

    fun getXp(): Int = prefs.getInt(KEY_XP, 0)

    fun addXp(amount: Int) {
        prefs.edit().putInt(KEY_XP, getXp() + amount).apply()
    }

    fun getLevelNumber(): Int = (getXp() / 200) + 1

    fun getCompletedLessons(): Set<Int> =
        prefs.getStringSet(KEY_COMPLETED_LESSONS, emptySet())
            ?.mapNotNull { it.toIntOrNull() }
            ?.toSet() ?: emptySet()

    fun markLessonCompleted(lessonId: Int) {
        val current = getCompletedLessons().map { it.toString() }.toMutableSet()
        current.add(lessonId.toString())
        prefs.edit().putStringSet(KEY_COMPLETED_LESSONS, current).apply()
        updateStreak()
    }

    fun isLessonCompleted(lessonId: Int): Boolean = getCompletedLessons().contains(lessonId)

    fun getProgressPercent(totalLessons: Int): Int {
        if (totalLessons == 0) return 0
        return (getCompletedLessons().size * 100) / totalLessons
    }

    fun getStreak(): Int = prefs.getInt(KEY_STREAK, 0)

    private fun updateStreak() {
        val today = dateFormat.format(Date())
        val lastDate = prefs.getString(KEY_LAST_DATE, null)
        if (lastDate == today) return

        val newStreak = if (lastDate == null) {
            1
        } else {
            val diffDays = try {
                val last = dateFormat.parse(lastDate)
                val now = dateFormat.parse(today)
                if (last != null && now != null) {
                    ((now.time - last.time) / (1000 * 60 * 60 * 24)).toInt()
                } else {
                    999
                }
            } catch (e: Exception) {
                999
            }
            if (diffDays == 1) getStreak() + 1 else 1
        }

        prefs.edit()
            .putInt(KEY_STREAK, newStreak)
            .putString(KEY_LAST_DATE, today)
            .apply()
    }

    fun getLearnedWords(): Set<String> =
        prefs.getStringSet(KEY_LEARNED_WORDS, emptySet()) ?: emptySet()

    fun addLearnedWords(words: List<String>) {
        val current = getLearnedWords().toMutableSet()
        current.addAll(words)
        prefs.edit().putStringSet(KEY_LEARNED_WORDS, current).apply()
    }
}
