package com.learentr.app.data

sealed class QuizQuestion {

    data class MultipleChoice(
        val questionText: String,
        val options: List<String>,
        val correctIndex: Int
    ) : QuizQuestion()

    data class FillBlank(
        val sentenceWithBlank: String,
        val fullSentenceAr: String,
        val options: List<String>,
        val correctIndex: Int
    ) : QuizQuestion()

    data class WordOrder(
        val translationAr: String,
        val scrambledWords: List<String>,
        val correctOrder: List<String>
    ) : QuizQuestion()
}

/**
 * Builds a randomized quiz session out of a lesson's word list.
 * Produces: TR->AR multiple choice, AR->TR multiple choice,
 * sentence completion, and word-ordering questions.
 */
object QuizEngine {

    fun generateQuiz(lesson: Lesson, questionCount: Int = 12): List<QuizQuestion> {
        val words = lesson.words
        val questions = mutableListOf<QuizQuestion>()

        words.forEach { word ->
            questions.add(buildTrToAr(word, words))
            questions.add(buildArToTr(word, words))
            questions.add(buildFillBlank(word, words))
        }

        words.filter { it.exampleTr.trim().split(" ").size in 2..6 }.forEach { word ->
            questions.add(buildWordOrder(word))
        }

        return questions.shuffled().take(questionCount.coerceAtMost(questions.size))
    }

    private fun buildTrToAr(word: Word, all: List<Word>): QuizQuestion.MultipleChoice {
        val distractors = all.filter { it != word }.shuffled().take(3).map { it.ar }
        val options = (distractors + word.ar).shuffled()
        return QuizQuestion.MultipleChoice(
            questionText = "ما معنى كلمة \"${word.tr}\"؟",
            options = options,
            correctIndex = options.indexOf(word.ar)
        )
    }

    private fun buildArToTr(word: Word, all: List<Word>): QuizQuestion.MultipleChoice {
        val distractors = all.filter { it != word }.shuffled().take(3).map { it.tr }
        val options = (distractors + word.tr).shuffled()
        return QuizQuestion.MultipleChoice(
            questionText = "كيف تقول \"${word.ar}\" بالتركية؟",
            options = options,
            correctIndex = options.indexOf(word.tr)
        )
    }

    private fun buildFillBlank(word: Word, all: List<Word>): QuizQuestion.FillBlank {
        val blanked = if (word.exampleTr.contains(word.tr)) {
            word.exampleTr.replaceFirst(word.tr, "____")
        } else {
            "____   (${word.exampleTr})"
        }
        val distractors = all.filter { it != word }.shuffled().take(3).map { it.tr }
        val options = (distractors + word.tr).shuffled()
        return QuizQuestion.FillBlank(
            sentenceWithBlank = blanked,
            fullSentenceAr = word.exampleAr,
            options = options,
            correctIndex = options.indexOf(word.tr)
        )
    }

    private fun buildWordOrder(word: Word): QuizQuestion.WordOrder {
        val correctOrder = word.exampleTr.trim()
            .trimEnd('.', '?', '!')
            .split(" ")
            .filter { it.isNotBlank() }
        return QuizQuestion.WordOrder(
            translationAr = word.exampleAr,
            scrambledWords = correctOrder.shuffled(),
            correctOrder = correctOrder
        )
    }
}
