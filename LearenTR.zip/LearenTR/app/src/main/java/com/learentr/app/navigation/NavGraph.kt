package com.learentr.app.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.learentr.app.ui.screens.HomeScreen
import com.learentr.app.ui.screens.LessonDetailScreen
import com.learentr.app.ui.screens.LessonListScreen
import com.learentr.app.ui.screens.LevelsScreen
import com.learentr.app.ui.screens.QuizScreen
import com.learentr.app.ui.screens.VocabularyScreen

private object Routes {
    const val HOME = "home"
    const val LEVELS = "levels"
    const val LESSON_LIST = "lessonList/{levelId}"
    const val LESSON_DETAIL = "lessonDetail/{lessonId}"
    const val QUIZ = "quiz/{lessonId}"
    const val VOCABULARY = "vocabulary"

    fun lessonList(levelId: String) = "lessonList/$levelId"
    fun lessonDetail(lessonId: Int) = "lessonDetail/$lessonId"
    fun quiz(lessonId: Int) = "quiz/$lessonId"
}

@Composable
fun LearenNavGraph() {
    val navController = rememberNavController()

    NavHost(navController = navController, startDestination = Routes.HOME) {
        composable(Routes.HOME) {
            HomeScreen(
                onStartLearning = { navController.navigate(Routes.LEVELS) },
                onOpenVocabulary = { navController.navigate(Routes.VOCABULARY) }
            )
        }
        composable(Routes.LEVELS) {
            LevelsScreen(
                onLevelSelected = { levelId -> navController.navigate(Routes.lessonList(levelId)) },
                onBack = { navController.popBackStack() }
            )
        }
        composable(
            Routes.LESSON_LIST,
            arguments = listOf(navArgument("levelId") { type = NavType.StringType })
        ) { backStackEntry ->
            val levelId = backStackEntry.arguments?.getString("levelId") ?: "A1"
            LessonListScreen(
                levelId = levelId,
                onLessonSelected = { lessonId -> navController.navigate(Routes.lessonDetail(lessonId)) },
                onBack = { navController.popBackStack() }
            )
        }
        composable(
            Routes.LESSON_DETAIL,
            arguments = listOf(navArgument("lessonId") { type = NavType.IntType })
        ) { backStackEntry ->
            val lessonId = backStackEntry.arguments?.getInt("lessonId") ?: 1
            LessonDetailScreen(
                lessonId = lessonId,
                onStartQuiz = { navController.navigate(Routes.quiz(lessonId)) },
                onBack = { navController.popBackStack() }
            )
        }
        composable(
            Routes.QUIZ,
            arguments = listOf(navArgument("lessonId") { type = NavType.IntType })
        ) { backStackEntry ->
            val lessonId = backStackEntry.arguments?.getInt("lessonId") ?: 1
            QuizScreen(
                lessonId = lessonId,
                onFinish = {
                    navController.popBackStack(Routes.HOME, false)
                }
            )
        }
        composable(Routes.VOCABULARY) {
            VocabularyScreen(onBack = { navController.popBackStack() })
        }
    }
}
