package com.learentr.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.learentr.app.data.LessonsData
import com.learentr.app.data.ProgressManager
import com.learentr.app.ui.components.LearenTopBar

@Composable
fun LessonDetailScreen(
    lessonId: Int,
    onStartQuiz: () -> Unit,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val progressManager = remember { ProgressManager(context) }
    val lesson = remember(lessonId) { LessonsData.a1Lessons.first { it.id == lessonId } }

    Column(modifier = Modifier.fillMaxSize()) {
        LearenTopBar(title = "${lesson.icon} ${lesson.titleAr}", onBack = onBack)

        LazyColumn(
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(lesson.words) { word ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(text = word.tr, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Text(text = word.ar, style = MaterialTheme.typography.titleMedium)
                        }
                        Text(
                            text = "النطق: ${word.pronunciation}",
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(text = word.exampleTr, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
                        Text(text = word.exampleAr, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }

        Button(
            onClick = {
                progressManager.addLearnedWords(lesson.words.map { it.tr })
                onStartQuiz()
            },
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
                .height(56.dp),
            shape = RoundedCornerShape(16.dp)
        ) {
            Text(text = "ابدأ الاختبار", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        }
    }
}
