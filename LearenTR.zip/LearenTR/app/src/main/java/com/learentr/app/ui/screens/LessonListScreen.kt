package com.learentr.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.learentr.app.data.LessonsData
import com.learentr.app.data.ProgressManager
import com.learentr.app.ui.components.LearenTopBar

@Composable
fun LessonListScreen(
    levelId: String,
    onLessonSelected: (Int) -> Unit,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val progressManager = remember { ProgressManager(context) }
    val lessons = LessonsData.a1Lessons

    Column(modifier = Modifier.fillMaxSize()) {
        LearenTopBar(title = "دروس المستوى $levelId", onBack = onBack)
        LazyColumn(
            contentPadding = PaddingValues(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(lessons) { lesson ->
                val completed = progressManager.isLessonCompleted(lesson.id)
                Card(
                    onClick = { onLessonSelected(lesson.id) },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "${lesson.icon}  ${lesson.titleAr}",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "${lesson.words.size} كلمات",
                                style = MaterialTheme.typography.bodyMedium
                            )
                        }
                        if (completed) {
                            Text(text = "✅", style = MaterialTheme.typography.titleMedium)
                        }
                    }
                }
            }
        }
    }
}
