package com.learentr.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.learentr.app.ui.components.LearenTopBar

private data class LevelInfo(
    val id: String,
    val title: String,
    val subtitle: String,
    val available: Boolean
)

private val levels = listOf(
    LevelInfo("A1", "A1 - المبتدئ", "التحيات، الأرقام، العائلة والمزيد", true),
    LevelInfo("A2", "A2 - الأساسي", "قريبًا", false),
    LevelInfo("B1", "B1 - المتوسط", "قريبًا", false),
    LevelInfo("B2", "B2 - فوق المتوسط", "قريبًا", false),
    LevelInfo("C1", "C1 - المتقدم", "قريبًا", false)
)

@Composable
fun LevelsScreen(
    onLevelSelected: (String) -> Unit,
    onBack: () -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        LearenTopBar(title = "المستويات", onBack = onBack)
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            items(levels) { level ->
                LevelCard(level = level, onClick = { if (level.available) onLevelSelected(level.id) })
            }
        }
    }
}

@Composable
private fun LevelCard(level: LevelInfo, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (level.available) MaterialTheme.colorScheme.surface
            else MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(text = level.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(text = level.subtitle, style = MaterialTheme.typography.bodyMedium)
            }
            if (!level.available) {
                Text(text = "🔒", style = MaterialTheme.typography.titleMedium)
            }
        }
    }
}
