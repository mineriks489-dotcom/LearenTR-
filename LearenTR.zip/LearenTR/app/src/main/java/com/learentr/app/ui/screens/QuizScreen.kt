package com.learentr.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.learentr.app.data.LessonsData
import com.learentr.app.data.ProgressManager
import com.learentr.app.data.QuizEngine
import com.learentr.app.data.QuizQuestion
import com.learentr.app.ui.components.AnswerOption
import com.learentr.app.ui.components.FlowRowWords
import com.learentr.app.ui.components.LearenTopBar

@Composable
fun QuizScreen(
    lessonId: Int,
    onFinish: () -> Unit
) {
    val context = LocalContext.current
    val progressManager = remember { ProgressManager(context) }
    val lesson = remember(lessonId) { LessonsData.a1Lessons.first { it.id == lessonId } }
    val questions = remember(lessonId) { QuizEngine.generateQuiz(lesson) }

    var currentIndex by remember { mutableStateOf(0) }
    var correctCount by remember { mutableStateOf(0) }
    var selectedAnswer by remember { mutableStateOf<String?>(null) }
    var showResult by remember { mutableStateOf(false) }
    var quizFinished by remember { mutableStateOf(false) }
    var orderedWords by remember { mutableStateOf(listOf<String>()) }

    if (quizFinished) {
        QuizResultScreen(
            correct = correctCount,
            total = questions.size,
            onFinish = {
                progressManager.addXp(correctCount * 10)
                progressManager.markLessonCompleted(lessonId)
                onFinish()
            }
        )
        return
    }

    val question = questions.getOrNull(currentIndex)
    if (question == null) {
        quizFinished = true
        return
    }

    Column(modifier = Modifier.fillMaxSize()) {
        LearenTopBar(title = "اختبار: ${lesson.titleAr}")

        LinearProgressIndicator(
            progress = { (currentIndex + 1) / questions.size.toFloat() },
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
        )
        Text(
            text = "${currentIndex + 1} / ${questions.size}",
            modifier = Modifier.padding(start = 20.dp, top = 6.dp),
            style = MaterialTheme.typography.bodyMedium
        )

        Column(
            modifier = Modifier
                .weight(1f)
                .padding(20.dp)
        ) {
            when (question) {
                is QuizQuestion.MultipleChoice -> {
                    Text(
                        text = question.questionText,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(20.dp))
                    question.options.forEach { option ->
                        AnswerOption(
                            text = option,
                            selected = selectedAnswer == option,
                            correct = if (showResult) option == question.options[question.correctIndex] else null,
                            enabled = !showResult,
                            onClick = { selectedAnswer = option }
                        )
                    }
                }

                is QuizQuestion.FillBlank -> {
                    Text(text = "أكمل الجملة:", style = MaterialTheme.typography.titleMedium)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = question.sentenceWithBlank,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Text(text = question.fullSentenceAr, style = MaterialTheme.typography.bodyMedium)
                    Spacer(modifier = Modifier.height(20.dp))
                    question.options.forEach { option ->
                        AnswerOption(
                            text = option,
                            selected = selectedAnswer == option,
                            correct = if (showResult) option == question.options[question.correctIndex] else null,
                            enabled = !showResult,
                            onClick = { selectedAnswer = option }
                        )
                    }
                }

                is QuizQuestion.WordOrder -> {
                    Text(text = "رتب الكلمات لتكوين الجملة الصحيحة:", style = MaterialTheme.typography.titleMedium)
                    Text(text = question.translationAr, style = MaterialTheme.typography.bodyMedium)
                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = if (orderedWords.isEmpty()) "…" else orderedWords.joinToString(" "),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )

                    if (orderedWords.isNotEmpty() && !showResult) {
                        TextButton(onClick = { orderedWords = listOf(); selectedAnswer = null }) {
                            Text(text = "🔄 إعادة")
                        }
                    }

                    val remainingWords = remember(question, orderedWords) {
                        val used = orderedWords.toMutableList()
                        question.scrambledWords.filter { word ->
                            if (used.contains(word)) {
                                used.remove(word)
                                false
                            } else {
                                true
                            }
                        }
                    }

                    FlowRowWords(
                        words = remainingWords,
                        onWordClick = { word ->
                            if (!showResult) {
                                val newOrder = orderedWords + word
                                orderedWords = newOrder
                                selectedAnswer = if (newOrder.size == question.correctOrder.size) {
                                    newOrder.joinToString(" ")
                                } else {
                                    null
                                }
                            }
                        }
                    )
                }
            }
        }

        Button(
            onClick = {
                if (!showResult) {
                    val isCorrect = when (question) {
                        is QuizQuestion.MultipleChoice ->
                            selectedAnswer == question.options[question.correctIndex]
                        is QuizQuestion.FillBlank ->
                            selectedAnswer == question.options[question.correctIndex]
                        is QuizQuestion.WordOrder ->
                            orderedWords == question.correctOrder
                    }
                    if (isCorrect) correctCount++
                    showResult = true
                } else {
                    selectedAnswer = null
                    showResult = false
                    orderedWords = listOf()
                    currentIndex++
                }
            },
            enabled = showResult || selectedAnswer != null,
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
                .height(56.dp),
            shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)
        ) {
            Text(
                text = if (showResult) "التالي" else "تحقق",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
