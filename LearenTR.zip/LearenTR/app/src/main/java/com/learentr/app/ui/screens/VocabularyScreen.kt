package com.learentr.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.learentr.app.data.LessonsData
import com.learentr.app.data.ProgressManager
import com.learentr.app.ui.components.LearenTopBar

@Composable
fun VocabularyScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val progressManager = remember { ProgressManager(context) }
    val learnedWords = progressManager.getLearnedWords()
    val allWords = LessonsData.a1Lessons.flatMap { it.words }
    val myWords = allWords.filter { learnedWords.contains(it.tr) }

    Column(modifier = Modifier.fillMaxSize()) {
        LearenTopBar(title = "مفرداتي (${myWords.size})", onBack = onBack)

        if (myWords.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(
                    text = "لم تتعلم أي كلمات بعد. ابدأ درسًا أولًا!",
                    style = MaterialTheme.typography.bodyLarge,
                    modifier = Modifier.padding(32.dp)
                )
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(20.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(myWords) { word ->
                    Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(text = word.tr, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                                Text(text = word.ar, style = MaterialTheme.typography.titleMedium)
                            }
                            Text(text = word.pronunciation, style = MaterialTheme.typography.bodyMedium)
                            Text(text = word.exampleTr, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            }
        }
    }
}
