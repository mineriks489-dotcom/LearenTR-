package com.learentr.app.ui.theme

import androidx.compose.ui.graphics.Color

val TealPrimary = Color(0xFF1F8A70)
val TealPrimaryDark = Color(0xFF3FBFA0)
val AmberAccent = Color(0xFFF5A623)
val BackgroundLight = Color(0xFFF7F9F8)
val BackgroundDark = Color(0xFF10201C)
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceDark = Color(0xFF1B2E28)
val ErrorRed = Color(0xFFE05252)
val SuccessGreen = Color(0xFF2FB380)
